function A1(){
    // console.log("1");
    window.location.href="./in.html";
}